#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtNetwork/QUdpSocket>
#include <QtNetwork/QNetworkInterface>
#include <QtNetwork/QNetworkAddressEntry>
#include <QDataStream>
#include <QObject>
#include <QProcess>
#include <QTextStream>

#define CONPORT 4879
#define SENDPORT 4878

#define NMSGDELIM "|#|#poop__"

#define NMSGPROTOCOLKEY "Some Shit Written By QT"
#define NSENDPROTOCOLKEY "Some Send Shit Written By QT"

#define NMSGPROTOCOLPC 4
#define NSENDPROTOCOLPC 2

bool checkProcIsLaunched(QString ProcessName);

QList<QNetworkInterface> getInterface();

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    QUdpSocket  *datasocket;
    QUdpSocket  *sendsocket;

private:
    Ui::MainWindow *ui;

private slots:
    void datasocketread();

};

#endif // MAINWINDOW_H
