#include "SimplePerformanceLib.h"

SystemMetricsGetter *sgm = nullptr;

void InitSPL()
{
    if (sgm == nullptr)
    {
        sgm = new SystemMetricsGetter;
        sgm->Init();
        sgm->InitMem();
    }
}

UINT16 GetProcessorPerformanceCur()
{
    if (sgm != nullptr) return sgm->GetProcessorUsage();
    else return  ZG_ERR_MEM_LOAD;
}

UINT16 GetProcessorPerformanceAvg()
{
    if (sgm != nullptr) return sgm->GetProcessorUsageMean();
    else return  ZG_ERR_MEM_LOAD;
}

UINT16 GetProcessorPerformanceMax()
{
    if (sgm != nullptr) return sgm->GetProcessorUsageMax();
    else return  ZG_ERR_MEM_LOAD;
}

UINT16 GetMemoryPerformanceCur()
{
    if (sgm != nullptr) return sgm->GetMemoryUsage();
    else return  ZG_ERR_MEM_LOAD;
}

UINT16 GetMemoryPerformanceAvg()
{
    if (sgm != nullptr) return sgm->GetMemoryUsageMean();
    else return  ZG_ERR_MEM_LOAD;
}

UINT16 GetMemoryPerformanceMax()
{
    if (sgm != nullptr) return sgm->GetMemoryUsageMax();
    else return  ZG_ERR_MEM_LOAD;
}

void CloseSPL()
{
    if (sgm != nullptr)
    {
        sgm->BurnMem();
        sgm->Burn();
        delete sgm;
    }
}

