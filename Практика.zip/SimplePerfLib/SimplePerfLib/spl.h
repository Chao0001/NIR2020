#ifndef _INC_WINDOWS
    #include <Windows.h>
#endif

extern "C"
{
    extern __declspec(dllimport) void InitSPL();

    extern __declspec(dllimport) UINT16 GetProcessorPerformanceCur();
    extern __declspec(dllimport) UINT16 GetProcessorPerformanceAvg();
    extern __declspec(dllimport) UINT16 GetProcessorPerformanceMax();

    extern __declspec(dllimport) UINT16 GetMemoryPerformanceCur();
    extern __declspec(dllimport) UINT16 GetMemoryPerformanceAvg();
    extern __declspec(dllimport) UINT16 GetMemoryPerformanceMax();

    extern __declspec(dllimport) void CloseSPL();
}