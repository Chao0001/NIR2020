#include "SystemMetricsGetter.hpp"

WMI_INIT_STATUS SystemMetricsGetter::Init()
{
	HRESULT st1 = S_OK;
	HRESULT st2 = S_OK;
	HRESULT st3 = S_OK;
	HRESULT st4 = S_OK;
	HRESULT st5 = S_OK;

	st1 = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
	if (FAILED(st1))
		return WMI_INIT_RESULT(st1, st2, st3, st4, st5);

	st2 = CoInitializeSecurity(
		NULL,
		-1,                          // COM authentication
		NULL,                        // Authentication services
		NULL,                        // Reserved
		RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
		RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
		NULL,                        // Authentication info
		EOAC_NONE,                   // Additional capabilities 
		NULL                         // Reserved
	);

	if (FAILED(st2))
	{
		CoUninitialize();
		return WMI_INIT_RESULT(st1, st2, st3, st4, st5);
	}

	st3 = CoCreateInstance(
		CLSID_WbemLocator,
		0,
		CLSCTX_INPROC_SERVER,
		IID_IWbemLocator, (LPVOID *)&wmiloc);

	if (FAILED(st3))
	{
		CoUninitialize();
		return WMI_INIT_RESULT(st1, st2, st3, st4, st5);
	}

	st4 = wmiloc->ConnectServer(
		_bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
		NULL,                    // User name. NULL = current user
		NULL,                    // User password. NULL = current
		0,                       // Locale. NULL indicates current
		NULL,                    // Security flags.
		0,                       // Authority (for example, Kerberos)
		0,                       // Context object 
		&wmiserv                    // pointer to IWbemServices proxy
	);

	if (FAILED(st4))
	{
		wmiloc->Release();
		CoUninitialize();
		return WMI_INIT_RESULT(st1, st2, st3, st4, st5);
	}

	st5 = CoSetProxyBlanket(
		wmiserv,                     // Indicates the proxy to set
		RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
		RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
		NULL,                        // Server principal name 
		RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
		RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
		NULL,                        // client identity
		EOAC_NONE                    // proxy capabilities 
	);

    if (this->metricsproc == nullptr) this->metricsproc = new std::vector<UINT16>;

	return WMI_INIT_RESULT(st1, st2, st3, st4, st5);
}

void SystemMetricsGetter::Burn()
{
    if (this->metricsproc != nullptr) delete this->metricsproc;

    if (wmiserv != nullptr) wmiserv->Release();

	if (wmiloc != nullptr) wmiloc->Release();

	CoUninitialize();
}

void SystemMetricsGetter::InitMem()
{
    if (this->metricsmem == nullptr) this->metricsmem = new std::vector<UINT16>;
}

void SystemMetricsGetter::BurnMem()
{
    if (this->metricsmem != nullptr) delete this->metricsmem;
}

UINT16 SystemMetricsGetter::GetProcessorUsage()
{
	UINT16 result = 0;

	IEnumWbemClassObject* pEnumerator = NULL;

	wmiserv->ExecQuery(
		bstr_t("WQL"),
		bstr_t("SELECT * FROM CIM_PROCESSOR"),
		WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY,
		NULL,
		&pEnumerator);

	IWbemClassObject *pclsObj = NULL;
	ULONG uReturn = 0;

	while (pEnumerator)
	{
		HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1,
			&pclsObj, &uReturn);

		if (0 == uReturn)
		{
			break;
		}

		VARIANT vtProp;

		hr = pclsObj->Get(L"LoadPercentage", 0, &vtProp, 0, 0);
		result = vtProp.uiVal;
		VariantClear(&vtProp);

		pclsObj->Release();
	}

	pEnumerator->Release();

    if ((*this->metricsproc).size() > ZG_MAX_MEAN_COUNT)
        this->metricsproc->clear();

    this->metricsproc->push_back(result);

	return result;
}

UINT16 SystemMetricsGetter::GetProcessorUsageMean()
{
    if (metricsproc->size() == 0) GetProcessorUsage();

    UINT32 sumval = 0;

    for (auto i = this->metricsproc->begin(); i != this->metricsproc->end(); ++i)
        sumval += *i;

    return (sumval / this->metricsproc->size());
}

UINT16 SystemMetricsGetter::GetProcessorUsageMax()
{
    if (metricsproc->size() == 0) GetProcessorUsage();
    return *std::max_element(metricsproc->begin(), metricsproc->end());
}

UINT16 SystemMetricsGetter::GetMemoryUsage()
{
    UINT16 result = 0;

    MEMORYSTATUSEX memoryinfo = { 0 };
    memoryinfo.dwLength = sizeof(memoryinfo);

    if (GlobalMemoryStatusEx(&memoryinfo))
    {
        if ((*this->metricsmem).size() > ZG_MAX_MEAN_COUNT)
            this->metricsmem->clear();

        this->metricsmem->push_back(memoryinfo.dwLength);

        return memoryinfo.dwMemoryLoad;
    }

    return ZG_ERR_MEM_LOAD;
}

UINT16 SystemMetricsGetter::GetMemoryUsageMean()
{
    if (metricsmem->size() == 0) GetMemoryUsage();

    UINT32 sumval = 0;

    for (auto i = this->metricsmem->begin(); i != this->metricsmem->end(); ++i)
        sumval += *i;

    return (sumval / (*this->metricsmem).size());
}

UINT16 SystemMetricsGetter::GetMemoryUsageMax()
{
    if (metricsmem->size() == 0) GetMemoryUsage();
    return *std::max_element(metricsmem->begin(), metricsmem->end());
}
