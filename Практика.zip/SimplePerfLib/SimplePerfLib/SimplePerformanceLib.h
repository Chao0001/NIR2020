#include "SystemMetricsGetter.hpp"

extern "C"
{
    extern __declspec(dllexport) void InitSPL();

    extern __declspec(dllexport) UINT16 GetProcessorPerformanceCur();
    extern __declspec(dllexport) UINT16 GetProcessorPerformanceAvg();
    extern __declspec(dllexport) UINT16 GetProcessorPerformanceMax();

    extern __declspec(dllexport) UINT16 GetMemoryPerformanceCur();
    extern __declspec(dllexport) UINT16 GetMemoryPerformanceAvg();
    extern __declspec(dllexport) UINT16 GetMemoryPerformanceMax();

    extern __declspec(dllexport) void CloseSPL();
}