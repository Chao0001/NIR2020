
#ifndef __INC_SystemMetricsGetter_HPP__
#define __INC_SystemMetricsGetter_HPP__

#define _WIN32_DCOM

#ifndef _INC_WINDOWS
    #include <Windows.h>
#endif

#ifndef _INC_COMDEF
    #include <comdef.h>
#endif

#ifndef __WBEMIDL_H_
    #include <WbemIdl.h>
#endif

#ifndef _TUPLE_
    #include <tuple>
#endif

#ifndef _LIST_
    #include <list>
#endif

#ifndef _VECTOR_
    #include <vector>
#endif

#ifndef _ALGORITHM_
    #include <algorithm>
#endif

#pragma comment(lib, "wbemuuid.lib")

#define ZG_MAX_MEAN_COUNT (size_t)100
#define ZG_ERR_MEM_LOAD 146

typedef std::tuple<HRESULT, HRESULT, HRESULT, HRESULT, HRESULT> WMI_INIT_STATUS;

#define WMI_INIT_SUCCESS(a) ((std::get<0>(a) == S_OK) && (std::get<1>(a) == S_OK) && (std::get<2>(a) == S_OK) && (std::get<3>(a) == S_OK) && (std::get<4>(a) == S_OK))
#define WMI_INIT_ST1FAIL(a) (FAILED(std::get<0>(a)))
#define WMI_INIT_ST2FAIL(a) (FAILED(std::get<1>(a)))
#define WMI_INIT_ST3FAIL(a) (FAILED(std::get<2>(a)))
#define WMI_INIT_ST4FAIL(a) (FAILED(std::get<3>(a)))
#define WMI_INIT_ST5FAIL(a) (FAILED(std::get<4>(a)))

#define WMI_INIT_RESULT(st1, st2, st3, st4, st5) std::make_tuple(st1, st2, st3, st4, st5)

class SystemMetricsGetter
{
private:
	IWbemLocator *wmiloc = nullptr;
	IWbemServices *wmiserv = nullptr;

    std::vector<UINT16> *metricsproc = nullptr;
    std::vector<UINT16> *metricsmem = nullptr;
public:
	WMI_INIT_STATUS Init();
	void			Burn();
    void            InitMem();
    void            BurnMem();

	UINT16			GetProcessorUsage();
    UINT16          GetProcessorUsageMean();
    UINT16          GetProcessorUsageMax();

    UINT16          GetMemoryUsage();
    UINT16          GetMemoryUsageMean();
    UINT16          GetMemoryUsageMax();
};

#endif