#include <iostream>
#include <spl.h>

using namespace std;

int main(int argc, char **argv)
{
    InitSPL();

    cout << GetProcessorPerformanceCur() << endl;

    CloseSPL();

    cin.get();
    return 0;
}