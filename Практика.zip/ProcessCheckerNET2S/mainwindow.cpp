#include "mainwindow.h"
#include "ui_mainwindow.h"

bool checkProcIsLaunched(QString ProcessName)
{
    WCHAR   fname[MAX_PATH];
    ProcessName.toWCharArray(fname);

    HANDLE scanproc = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (scanproc == INVALID_HANDLE_VALUE) return false;
    PROCESSENTRY32W processList;
    processList.dwSize = sizeof(PROCESSENTRY32W);
    BOOL result = Process32FirstW(scanproc, &processList);

    if (result)
    {
        while (Process32NextW(scanproc, &processList))
        {
            if (wcsstr(fname, processList.szExeFile) != nullptr)
            {
                CloseHandle(scanproc);
                return true;
            }
        }
     }

    CloseHandle(scanproc);
    return false;
}

QList<QNetworkInterface> getInterface()
{
    //берем все интерфейсы, которые есть в системе
       QList<QNetworkInterface> networkInterfaces = QNetworkInterface::allInterfaces();

       for(int i = 0; i < networkInterfaces.size(); i++)
       {
           QNetworkInterface::InterfaceFlags _flags = networkInterfaces.at(i).flags();
       //если интерфейс выключен или если это вообще loopback
           if(!(QNetworkInterface::IsUp & _flags) || (QNetworkInterface::IsLoopBack & _flags))
           {
           //то убираем его из списка
               networkInterfaces.removeAt(i);
           }
       }
       //возвращаем список работающих и активных интерфейсов
       return networkInterfaces;
}

void MainWindow::datasocketread()
{
    //MessageBoxW(nullptr, L"", L"", MB_OK);

    if (datasocket->hasPendingDatagrams())
    {
        QByteArray rawdata;
        rawdata.resize(datasocket->pendingDatagramSize());

        QHostAddress    addr;
        datasocket->readDatagram(rawdata.data(), rawdata.size(), &addr);

        QDataStream datain(&rawdata, QIODevice::ReadOnly);

        QString NormilizedMessage;

        datain >> NormilizedMessage;

        QStringList NMParts = NormilizedMessage.split(NMSGDELIM);

        if ((NMParts.count() == NSENDPROTOCOLPC) && (NMParts.at(0) == NSENDPROTOCOLKEY))
        {
            QString AnswerString(NMSGPROTOCOLKEY);
            AnswerString += NMSGDELIM;
            AnswerString += NMParts.at(1);
            AnswerString += NMSGDELIM;

            bool processState = checkProcIsLaunched(NMParts.at(1));

            if (processState)
                AnswerString += "Process Is Launched ;)";
            else
                AnswerString += "Process Is NOT Launched :(";

            AnswerString += NMSGDELIM;
            //AnswerString += addr.toString();

            QByteArray  requestData;
            QDataStream requestStream(&requestData, QIODevice::WriteOnly);

            //requestStream << AnswerString;

            QList<QNetworkInterface> NIList = getInterface();

            for (int i = 0; i < NIList.count(); ++i)
            {
                QList<QNetworkAddressEntry> addrs = NIList.at(i).addressEntries();
                for (int j = 0; j < addrs.count(); ++j)
                {
                    bool convOK = false;
                    QHostAddress addrV4(addrs.at(j).ip().toIPv4Address(&convOK));

                    QString AnswerString2;

                    if (convOK)
                         AnswerString2 = AnswerString + addrV4.toString();
                    else
                         AnswerString2 = AnswerString + addrs.at(j).ip().toString();

                    requestStream << AnswerString2;
                    sendsocket->writeDatagram(requestData, addrs.at(j).broadcast(), SENDPORT);
                }
            }
        }
    }
}

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    datasocket = new QUdpSocket();
    datasocket->bind(QHostAddress::Any, CONPORT);

    connect(datasocket, SIGNAL(readyRead()), this, SLOT(datasocketread()));

    sendsocket = new QUdpSocket();
    sendsocket->bind(QHostAddress::Broadcast, SENDPORT);
}

MainWindow::~MainWindow()
{
    delete sendsocket;
    delete datasocket;

    delete ui;
}
