#include "mainwindow.h"
#include "ui_mainwindow.h"

int pinghost(QString host)
{
    QStringList parameters;
    #if defined(WIN32)
       parameters << "-n" << "1";
    #else
       parameters << "-c 1";
    #endif

    parameters << host;

    int exitCode = QProcess::execute("ping", parameters);
    if (exitCode==0)
         return PCN_STATUS_NOT_READY;
    else
         return PCN_STATUS_NOT_RESOLVED;
}

QList<PCN_HOST> getKnownIP(QString path)
{
    QFile kif(path);
    kif.open(QIODevice::ReadOnly);

    QList<PCN_HOST> knownips = QList<PCN_HOST>();

    while (!kif.atEnd())
    {
        QString data = kif.readLine();
        QHostAddress addr(data);
        PCN_HOST host;
        host.host = addr;
        host.hostsendtime = 0;
        host.hoststatus = PCN_STATUS_NOT_RESOLVED;
        knownips.append(host);
    }

    kif.close();
    return knownips;
}

QList<QNetworkInterface> getInterface()
{
    //берем все интерфейсы, которые есть в системе
       QList<QNetworkInterface> networkInterfaces = QNetworkInterface::allInterfaces();

       for(int i = 0; i < networkInterfaces.size(); i++)
       {
           QNetworkInterface::InterfaceFlags _flags = networkInterfaces.at(i).flags();
       //если интерфейс выключен или если это вообще loopback
           if(!(QNetworkInterface::IsUp & _flags) || (QNetworkInterface::IsLoopBack & _flags))
           {
           //то убираем его из списка
               networkInterfaces.removeAt(i);
           }
       }
       //возвращаем список работающих и активных интерфейсов
       return networkInterfaces;
}

void MainWindow::datasocketread()
{
    if (datasocket->hasPendingDatagrams())
    {
        QByteArray rawdata;
        rawdata.resize(datasocket->pendingDatagramSize());

        QHostAddress    addr;
        datasocket->readDatagram(rawdata.data(), rawdata.size(), &addr);

        //this->setWindowTitle(QHostAddress(addr.toIPv4Address()).toString());
        for (int i = 0; i < KnownIPAddresses.count(); ++i)
        {
            if (ui->tableWidget_3->item(i, 0)->text() == QHostAddress(addr.toIPv4Address()).toString())
            {
                QTime time;
                qint32 rt = time.msecsSinceStartOfDay() - KnownIPAddresses[i].hostsendtime;
                ui->tableWidget_3->item(i, 1)->setText(QString::number(rt) + " ms");
                KnownIPAddresses[i].hoststatus = PCN_STATUS_SUCCESS;
            }
        }

        QDataStream datain(&rawdata, QIODevice::ReadOnly);

        QString NormilizedMessage;

        datain >> NormilizedMessage;

        QStringList NMParts = NormilizedMessage.split(NMSGDELIM);

        if ((NMParts.count() == NMSGPROTOCOLPC) && (NMParts.at(0) == NMSGPROTOCOLKEY))
        {
            for (int i = 0; i < ui->tableWidget->rowCount(); ++i)
            {
                if ((ui->tableWidget->item(i, 0)->text() == NMParts.at(1))
                        && (ui->tableWidget->item(i, 2)->text() == NMParts.at(3)))
                {
                    ui->tableWidget->item(i, 1)->setText(NMParts.at(2));
                    ui->tableWidget->item(i, 3)->setText(NMParts.at(4));
                    return;
                }
            }

            ui->tableWidget->setRowCount(ui->tableWidget->rowCount() + 1);
            ui->tableWidget->setItem(ui->tableWidget->rowCount() - 1, 0, new QTableWidgetItem(NMParts.at(1)));
            ui->tableWidget->setItem(ui->tableWidget->rowCount() - 1, 1, new QTableWidgetItem(NMParts.at(2)));
            ui->tableWidget->setItem(ui->tableWidget->rowCount() - 1, 2, new QTableWidgetItem(NMParts.at(3)));
            ui->tableWidget->setItem(ui->tableWidget->rowCount() - 1, 3, new QTableWidgetItem(NMParts.at(4)));
        }
    }
}

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget_2->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget_3->setEditTriggers(QAbstractItemView::NoEditTriggers);

    KnownIPAddresses = getKnownIP(QCoreApplication::applicationDirPath() + "/knownip.txt");

    for (int i = 0; i < KnownIPAddresses.count(); ++i)
    {
        ui->tableWidget_3->setRowCount(ui->tableWidget_3->rowCount() + 1);
        ui->tableWidget_3->setItem(ui->tableWidget_3->rowCount() - 1, 0, new QTableWidgetItem(KnownIPAddresses.at(i).host.toString()));
        ui->tableWidget_3->setItem(ui->tableWidget_3->rowCount() - 1, 1, new QTableWidgetItem(""));
    }

    datasocket = new QUdpSocket(this);
    datasocket->bind(QHostAddress::Any, CONPORT);

    connect(datasocket, SIGNAL(readyRead()), SLOT(datasocketread()));

    sendsocket = new QUdpSocket(this);
    sendsocket->bind(QHostAddress::Broadcast, SENDPORT);

    timer2 = new QTimer(this);
    timer2->setInterval(MAX_WAIT_TIMEOUT);
    connect(timer2, SIGNAL(timeout()), this, SLOT(timer2Update()));

    timer = new QTimer(this);
    timer->setInterval(SEND_TIME_INTERVAL);
    connect(timer, SIGNAL(timeout()), this, SLOT(timerUpdate()));
    timer->start();
}

MainWindow::~MainWindow()
{
    timer->stop();
    delete timer;

    timer2->stop();
    delete timer2;

    sendsocket->close();
    delete sendsocket;

    datasocket->close();
    delete datasocket;

    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QFileDialog opendialog(this);
    QString FileName(opendialog.getOpenFileName(this, "Select EXE", "", "EXE (*.exe)"));

    if (FileName != "")
    {

        QStringList OFN23 = FileName.split("/");

        for (int i = 0;  i < ui->tableWidget_2->rowCount(); ++i)
        {
            if (ui->tableWidget_2->item(i, 0)->text() == OFN23.at(OFN23.size()-1))
               return;
        }

        ui->tableWidget_2->setRowCount(ui->tableWidget_2->rowCount() + 1);
        ui->tableWidget_2->setItem(ui->tableWidget_2->rowCount() - 1,
                               0, new QTableWidgetItem(OFN23.at(OFN23.size()-1)));
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    if (ui->lineEdit->text() != "")
    {
        for (int i = 0;  i < ui->tableWidget_2->rowCount(); ++i)
        {
            if (ui->tableWidget_2->item(i, 0)->text() == ui->lineEdit->text())
               return;
        }

        ui->tableWidget_2->setRowCount(ui->tableWidget_2->rowCount() + 1);
        ui->tableWidget_2->setItem(ui->tableWidget_2->rowCount() - 1,
                               0, new QTableWidgetItem(ui->lineEdit->text()));
    }
}

void MainWindow::on_pushButton_3_clicked()
{
    if (ui->tableWidget_2->selectedItems().count() != 0)
    {
        ui->tableWidget_2->removeRow(ui->tableWidget_2->selectedItems().at(0)->row());
    }
}

void MainWindow::timerUpdate()
{
    //QMessageBox::information(this, "poop", "poop");
    QList<QNetworkInterface> NIList = getInterface();

    for (int i = 0; i < NIList.count(); ++i)
    {
        QList<QNetworkAddressEntry> addresses = NIList.at(i).addressEntries();
        for (int j = 0; j < addresses.count(); ++j)
        {
            for (int k = 0; k < ui->tableWidget_2->rowCount(); ++k)
            {
                QString requestString(NSENDPROTOCOLKEY);
                requestString += NMSGDELIM;
                requestString += ui->tableWidget_2->item(k, 0)->text();

                QByteArray  requestData;
                QDataStream requestStream(&requestData, QIODevice::WriteOnly);

                requestStream << requestString;

                sendsocket->writeDatagram(requestData, addresses.at(j).broadcast(), SENDPORT);
            }
        }
    }

    for (int k = 0; k < ui->tableWidget_2->rowCount(); ++k)
    {
        QString requestString(NSENDPROTOCOLKEY);
        requestString += NMSGDELIM;
        requestString += ui->tableWidget_2->item(k, 0)->text();

        QByteArray  requestData;
        QDataStream requestStream(&requestData, QIODevice::WriteOnly);

        requestStream << requestString;

        for (int i = 0; i < KnownIPAddresses.count(); ++i)
        {
            QTime time;
            KnownIPAddresses[i].hostsendtime = time.msecsSinceStartOfDay();
            sendsocket->writeDatagram(requestData, KnownIPAddresses.at(i).host, SENDPORT);
        }
    }

    //timer2->start();
}

void MainWindow::timer2Update()
{
    setWindowTitle("POOP");
    timer2->stop();
    for (int i = 0; i < KnownIPAddresses.count(); ++i)
    {
        if (KnownIPAddresses.at(i).hoststatus != PCN_STATUS_SUCCESS)
        {
            if (pinghost(KnownIPAddresses.at(i).host.toString()) == PCN_STATUS_NOT_READY)
                ui->tableWidget_3->item(i, 1)->setText("NOT READY");
            else
                ui->tableWidget_3->item(i, 1)->setText("NOT RESOLVED");
        }
    }
}
