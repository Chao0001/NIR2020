#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QCoreApplication>
#include <QMainWindow>
#include <QFileDialog>
#include <QTimer>
#include <QtNetwork/QUdpSocket>
#include <QtNetwork/QNetworkInterface>
#include <QtNetwork/QNetworkAddressEntry>
#include <QProcess>
#include <QMessageBox>
#include <QThread>
#include <QTime>

#define CONPORT 4878
#define SENDPORT 4879

#define NMSGDELIM "|#|#poop__"

#define NMSGPROTOCOLKEY "Some Shit Written By QT"
#define NSENDPROTOCOLKEY "Some Send Shit Written By QT"

#define NMSGPROTOCOLPC 5
#define NSENDPROTOCOLPC 2

#define PCN_STATUS_SUCCESS 0x000
#define PCN_STATUS_NOT_READY 0x105
#define PCN_STATUS_NOT_RESOLVED 0x106

#define MAX_WAIT_TIMEOUT 300
#define SEND_TIME_INTERVAL 500

typedef struct __PCN_HOST
{
   QHostAddress host;
   int         hoststatus;
   int          hostsendtime;
} PCN_HOST, *PPCN_HOST;

QList<QNetworkInterface> getInterface();
QList<PCN_HOST> getKnownIP();
int pinghost(QString host);

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    QUdpSocket  *datasocket;
    QUdpSocket  *sendsocket;
    QTimer      *timer = nullptr;
    QTimer      *timer2 = nullptr;
    QList<PCN_HOST> KnownIPAddresses;
private slots:
    void datasocketread();
    void timerUpdate();
    void timer2Update();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();


private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
